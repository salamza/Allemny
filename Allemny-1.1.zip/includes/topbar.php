<div class="container">         
            <ul id="loginbar" class="pull-right">

                    <li><i class="icon-globe"></i><a>Languages<i class="icon-sort-up"></i></a>
                    <ul class="nav-list">
                        <li class="active"><a href="#">English</a> <i class="icon-ok"></i></li>
                        <li class="disabled"><a href="#">Arabic</a></li>
                    </ul>
                </li>   
            <li class="devider">&nbsp;</li>
             <li ><a target="_blank" href="https://www.facebook.com/allemny"><img src="img/facebook.png" width="20" height="20" alt="Facebook" title="Facebook"/></a></li>
                    <li class="devider">&nbsp;</li>
                    <li ><a target="_blank" href="https://twitter.com/Allemny"><img src="img/twitter.png" width="20" height="20" alt="Twitter" title="Twitter" /></a></li>
                    <li class="devider">&nbsp;</li>
                    <li ><a target="_blank" style="margin-left:-1px" href="http://www.youtube.com/user/Allemny"><img src="img/youtube.png" width="20" height="20" alt="YouTube" title="YouTube" class="socialicon" /></a> </li>
                    <li class="devider">&nbsp;</li>
                     
            </ul>
        </div> 