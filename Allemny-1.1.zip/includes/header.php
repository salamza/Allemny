        <div id="header">               
            <div class="container"> 
                <div class="row-fluid">
                    <div class="span4">
                     <a href="index.php"><img src="img/logo.png" alt="Logo"></a>
                  </div>
                  <div class="span6 offset2">
                    <div style="width:400px; padding-top:55px; padding-left:41px">
                      <div class="navbar">
                        <div class="navbar-inner">
                          <div class="container">
                            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                              <span class="icon-bar"></span>
                              <span class="icon-bar"></span>
                              <span class="icon-bar"></span>
                          </a>
                          <div class="nav-collapse">
                              <ul class="nav">
                                <li><a href="courses">Courses</a></li>
                                <li><a href="about">About</a></li>
                                <li><a href="contact">Contact</a></li>
                                <li><a href="join">join&nbsp;us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<hr style="padding: 0 0 0 0;margin:0 0 0 0;">
</div> 