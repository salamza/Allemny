<head>
    <title>Allemny Initiative</title>        
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="css/style-menu.css">
    <link rel='stylesheet' type='text/css' href='css/fullcalendar.css' />
    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/modernizr.custom.js"></script>
    <script src="js/subscript.js"></script>
    <script type='text/javascript' src='js/fullcalendar.min.js'></script>
    <script type="text/javascript">
    $(document).ready(function() {
    $('#calendar').fullCalendar({
        //settings of calendar;
    })
});
    </script>
    <link rel="stylesheet" type="text/css" href="css/style-main.css">
    <?php
    error_reporting(0);
    ?>
</head>