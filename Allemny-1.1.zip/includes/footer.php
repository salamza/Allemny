
<div id="push"></div>
    </div>
    <div id="container">
<div id="footer" style="margin-top:20px;">
	<div id="container">
    <p style="width:1000px;margin:0px auto;padding-top:15px;">Copyright &copy; 2013 Allemny.org. All rights reserved.</p>
    			

    </div>
</div>
</div>