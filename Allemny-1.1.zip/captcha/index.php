<form action="submit.php" method="post"> 
Name: <input name="coment"><br><br>
<img src="captcha.php"><br><input type="text" name="vercode" /> 
<input type="submit" name="Submit" value="Submit" /> 
</form>
