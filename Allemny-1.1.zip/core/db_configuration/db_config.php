<?php
DEFINE ('db_hostname', 'localhost');
DEFINE ('db_database','allemny');
DEFINE ('db_username','root');
DEFINE ('db_password','');
?>