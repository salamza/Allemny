<?php 
include 'includes/overall/overallheader.php';?>


<div class="container">
	<div class="well">
		<h2>Join The Team.</h2>
		<p>Allemny is non-profitable project that was created in 2011 by Life Makers, Engineering College - Alexandria University. Allemny mainly aims to encourage self-Learning and to keep teaching techniques up to date by using new education tactics to cope with the modern technologies. We are creating short videos that explain engineering topics and software in an easy way, so that everybody can understand our data.<br>It is our belief that science and education have always been the principal foundation of civilization and progression of nations. It has become a necessity to enhance the outdated education tactics. We provide education for those who need it whenever they want. We are creating online Videos that illustrate scientific topics which help students who are interested in any of these topics to start searching and reading about them.</p><br>
		<p><B>Notice that you have the choice for registering in:</B><br></p>
		<ol>
			<li>HR Committee.</li>
			<li>The PR & Fundraising committee.</li>
			<li>Marketing Committee.</li>
			<li>Web Committee Containing three teams Web Developers, Designers,Editors.</li>
			<li>Research & Development committee</li>
			<li>Graphics Committee: Containing Three Sub-teams "Video Editing team", "Design team" and "Videography and Photography team".</li>
			<li>Academic Committee</li>

		</ol>
			<p>You can find the job description for each committee <a href="allemnyCommittees">Here</a> <br>
			<br></p>
			<h3 style="padding-left:200px;">Recruiting Will Start Soon, Stay Tuned...</h3>
		</div>
	</div>
	
	<?php 
	include 'includes/overall/overallfooter.php';?>